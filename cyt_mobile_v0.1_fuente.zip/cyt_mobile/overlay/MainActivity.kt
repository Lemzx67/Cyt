package app.cyt.cyt_mobile

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel

/**
 * Fase 2: descubrimiento local con NsdManager (mDNS). Solo observa la red;
 * no se conecta a ningun televisor.
 */
class MainActivity : FlutterActivity() {
    private val types = listOf(
        "_adb-tls-connect._tcp",   // Depuracion inalambrica: conexion
        "_adb-tls-pairing._tcp",   // Solo visible mientras el TV muestra el codigo de emparejamiento
        "_adb._tcp",               // ADB clasico anunciado por algunos equipos
        "_androidtvremote2._tcp"   // Android TV Remote: ayuda a identificar que es un TV
    )
    private val main = Handler(Looper.getMainLooper())
    private var sink: EventChannel.EventSink? = null
    private var nsd: NsdManager? = null
    private var lock: WifiManager.MulticastLock? = null
    private val listeners = mutableListOf<NsdManager.DiscoveryListener>()
    private val queue = ArrayDeque<NsdServiceInfo>()
    private var resolving = false

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val messenger = flutterEngine.dartExecutor.binaryMessenger
        MethodChannel(messenger, "cyt/discovery").setMethodCallHandler { call, result ->
            when (call.method) {
                "start" -> { start(); result.success(null) }
                "stop" -> { stop(); result.success(null) }
                else -> result.notImplemented()
            }
        }
        EventChannel(messenger, "cyt/discovery/events").setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(args: Any?, events: EventChannel.EventSink?) { sink = events }
            override fun onCancel(args: Any?) { sink = null }
        })
    }

    private fun emit(m: Map<String, Any>) { main.post { sink?.success(m) } }
    private fun norm(t: String) = t.trimEnd('.')

    private fun start() {
        if (listeners.isNotEmpty()) return
        val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        lock = wifi.createMulticastLock("cyt-mdns").apply { setReferenceCounted(false); acquire() }
        val mgr = getSystemService(Context.NSD_SERVICE) as NsdManager
        nsd = mgr
        for (t in types) {
            val l = object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(s: String) {}
                override fun onDiscoveryStopped(s: String) {}
                override fun onStartDiscoveryFailed(s: String, e: Int) {}
                override fun onStopDiscoveryFailed(s: String, e: Int) {}
                override fun onServiceFound(i: NsdServiceInfo) { enqueue(i) }
                override fun onServiceLost(i: NsdServiceInfo) {
                    emit(mapOf("event" to "lost", "name" to i.serviceName, "type" to norm(i.serviceType)))
                }
            }
            listeners.add(l)
            mgr.discoverServices(t, NsdManager.PROTOCOL_DNS_SD, l)
        }
    }

    // NsdManager solo resuelve un servicio a la vez: se encola.
    private fun enqueue(i: NsdServiceInfo) { main.post { queue.addLast(i); next() } }

    @Suppress("DEPRECATION")
    private fun next() {
        if (resolving) return
        val i = queue.removeFirstOrNull() ?: return
        resolving = true
        nsd?.resolveService(i, object : NsdManager.ResolveListener {
            override fun onResolveFailed(s: NsdServiceInfo, e: Int) {
                main.post { resolving = false; next() }
            }
            override fun onServiceResolved(s: NsdServiceInfo) {
                val host = s.host?.hostAddress
                if (host != null) {
                    emit(mapOf("event" to "found", "name" to s.serviceName,
                        "type" to norm(s.serviceType), "host" to host, "port" to s.port))
                }
                main.post { resolving = false; next() }
            }
        })
    }

    private fun stop() {
        listeners.forEach { try { nsd?.stopServiceDiscovery(it) } catch (_: Exception) {} }
        listeners.clear(); queue.clear(); resolving = false
        lock?.let { if (it.isHeld) it.release() }; lock = null
    }

    override fun onDestroy() { stop(); super.onDestroy() }
}
