// Fase 4 (parcial): esquema SQLite para historial, ejecuciones y cambios restaurables.
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

class Db {
  static Database? _db;

  static Future<Database> get() async {
    if (_db != null) return _db!;
    final path = p.join(await getDatabasesPath(), 'cyt.db');
    _db = await openDatabase(path, version: 1, onCreate: (d, v) async {
      await d.execute('CREATE TABLE devices('
          'id INTEGER PRIMARY KEY AUTOINCREMENT, host TEXT UNIQUE NOT NULL,'
          'label TEXT, model TEXT, last_seen INTEGER NOT NULL)');
      await d.execute('CREATE TABLE runs('
          'id INTEGER PRIMARY KEY AUTOINCREMENT, device_id INTEGER NOT NULL,'
          'kind TEXT NOT NULL, status TEXT NOT NULL, started_at INTEGER NOT NULL,'
          'finished_at INTEGER, FOREIGN KEY(device_id) REFERENCES devices(id))');
      // Un cambio = algo aplicado al TV y como deshacerlo.
      await d.execute('CREATE TABLE changes('
          'id INTEGER PRIMARY KEY AUTOINCREMENT, run_id INTEGER NOT NULL,'
          'package TEXT NOT NULL, action TEXT NOT NULL, prev_state TEXT,'
          'applied_at INTEGER NOT NULL, restored_at INTEGER,'
          'FOREIGN KEY(run_id) REFERENCES runs(id))');
    });
    return _db!;
  }

  static Future<int> upsertDevice(String host, {String? label}) async {
    final d = await get();
    final now = DateTime.now().millisecondsSinceEpoch;
    final rows = await d.query('devices', where: 'host = ?', whereArgs: [host]);
    if (rows.isEmpty) {
      return d.insert('devices', {'host': host, 'label': label, 'last_seen': now});
    }
    await d.update('devices', {'last_seen': now, if (label != null) 'label': label},
        where: 'host = ?', whereArgs: [host]);
    return rows.first['id'] as int;
  }

  static Future<List<Map<String, Object?>>> devices() async {
    final d = await get();
    return d.query('devices', orderBy: 'last_seen DESC');
  }

  static Future<List<Map<String, Object?>>> runs() async {
    final d = await get();
    return d.rawQuery('SELECT r.*, v.host FROM runs r JOIN devices v '
        'ON v.id = r.device_id ORDER BY r.started_at DESC');
  }
}
