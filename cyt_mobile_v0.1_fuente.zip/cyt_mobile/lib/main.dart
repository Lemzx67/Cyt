// Fase 1-2: interfaz y descubrimiento. El motor ADB/optimizacion NO existe aun:
// las pantallas que dependen de el lo dicen explicitamente en lugar de simular datos.
import 'package:flutter/material.dart';
import 'db.dart';
import 'discovery.dart';

void main() => runApp(const CytApp());

class CytApp extends StatelessWidget {
  const CytApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Clean Your TV Mobile',
        theme: ThemeData(colorSchemeSeed: Colors.teal, useMaterial3: true),
        darkTheme: ThemeData(
            colorSchemeSeed: Colors.teal, useMaterial3: true, brightness: Brightness.dark),
        home: const HomeScreen(),
      );
}

// 1. Inicio y estado del servicio
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Clean Your TV Mobile')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Card(
          child: ListTile(
            leading: Icon(Icons.radar),
            title: Text('Descubrimiento local'),
            subtitle: Text('Disponible (mDNS). Pendiente de validar en tu red.'),
          ),
        ),
        const Card(
          child: ListTile(
            leading: Icon(Icons.usb_off),
            title: Text('Motor ADB'),
            subtitle: Text('No verificado. Se valida en la Fase 3 con tu TV antes de '
                'activar diagnostico u optimizacion.'),
          ),
        ),
        const SizedBox(height: 8),
        FilledButton.icon(
          icon: const Icon(Icons.tv),
          label: const Text('Buscar televisores'),
          onPressed: () => Navigator.push(
              context, MaterialPageRoute(builder: (_) => const DiscoveryScreen())),
        ),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          icon: const Icon(Icons.history),
          label: const Text('Historial'),
          onPressed: () => Navigator.push(
              context, MaterialPageRoute(builder: (_) => const HistoryScreen())),
        ),
      ]),
    );
  }
}

// 2-3. Descubrimiento y seleccion
class DiscoveryScreen extends StatefulWidget {
  const DiscoveryScreen({super.key});
  @override
  State<DiscoveryScreen> createState() => _DiscoveryScreenState();
}

class _DiscoveryScreenState extends State<DiscoveryScreen> {
  final _d = Discovery();
  String? _error;

  @override
  void initState() {
    super.initState();
    _d.start().catchError((e) => setState(() => _error = '$e'));
  }

  @override
  void dispose() {
    _d.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Televisores en tu red')),
      body: _error != null
          ? Center(child: Text('Error: $_error'))
          : StreamBuilder<List<TvCandidate>>(
              stream: _d.stream,
              initialData: const [],
              builder: (context, snap) {
                final list = snap.data ?? const [];
                if (list.isEmpty) {
                  return const Padding(
                    padding: EdgeInsets.all(24),
                    child: Center(
                      child: Text('Buscando...\n\nSi no aparece nada: conecta el telefono '
                          'a la misma Wi-Fi que el TV y activa la depuracion inalambrica '
                          'en el TV (Opciones de desarrollador).',
                          textAlign: TextAlign.center),
                    ),
                  );
                }
                return ListView(children: [
                  for (final c in list)
                    ListTile(
                      leading: const Icon(Icons.tv),
                      title: Text(c.host),
                      subtitle: Wrap(spacing: 6, children: [
                        if (c.hasConnect) const Chip(label: Text('ADB inalambrico')),
                        if (c.hasPairing) const Chip(label: Text('Emparejando')),
                        if (c.hasLegacyAdb) const Chip(label: Text('ADB')),
                        if (c.hasRemote) const Chip(label: Text('Android TV')),
                      ]),
                      onTap: () async {
                        await Db.upsertDevice(c.host);
                        if (!context.mounted) return;
                        Navigator.push(context,
                            MaterialPageRoute(builder: (_) => GuideScreen(candidate: c)));
                      },
                    ),
                ]);
              },
            ),
    );
  }
}

// 4. Guia de conexion y autorizacion
class GuideScreen extends StatelessWidget {
  final TvCandidate candidate;
  const GuideScreen({super.key, required this.candidate});

  @override
  Widget build(BuildContext context) {
    const steps = [
      'En el TV: Ajustes > Preferencias del dispositivo > Acerca de > pulsa OK 7 veces en "Compilacion".',
      'Vuelve a Opciones de desarrollador y activa la depuracion inalambrica.',
      'Elige "Vincular dispositivo con codigo". El TV mostrara un codigo y un puerto.',
      'La autorizacion la das tu en el TV. Esta app no la omite ni la automatiza.',
    ];
    return Scaffold(
      appBar: AppBar(title: Text('Conectar ${candidate.host}')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        for (var i = 0; i < steps.length; i++)
          ListTile(leading: CircleAvatar(child: Text('${i + 1}')), title: Text(steps[i])),
        const Divider(),
        ListTile(
          leading: Icon(candidate.hasConnect ? Icons.check_circle : Icons.help_outline),
          title: Text(candidate.hasConnect
              ? 'El TV anuncia depuracion inalambrica (puerto ${candidate.ports['_adb-tls-connect._tcp']}).'
              : 'El TV aun no anuncia depuracion inalambrica.'),
        ),
        const SizedBox(height: 8),
        FilledButton(
          onPressed: () => Navigator.push(
              context, MaterialPageRoute(builder: (_) => const FlowScreen())),
          child: const Text('Continuar'),
        ),
      ]),
    );
  }
}

// 5-9. Diagnostico, tareas, progreso, informe, restauracion
class FlowScreen extends StatelessWidget {
  const FlowScreen({super.key});
  @override
  Widget build(BuildContext context) {
    const items = [
      (Icons.search, 'Diagnostico', 'Fase 5: lectura de modelo, paquetes y almacenamiento.'),
      (Icons.checklist, 'Tareas de optimizacion', 'Fase 6: seleccion con consentimiento explicito.'),
      (Icons.sync, 'Progreso', 'Fase 6: progreso real de cada operacion.'),
      (Icons.description, 'Informe final', 'Fase 6: resumen de lo aplicado.'),
      (Icons.restore, 'Restauracion', 'Fase 6: deshacer los cambios compatibles.'),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Siguientes pasos')),
      body: ListView(children: [
        const Padding(
          padding: EdgeInsets.all(16),
          child: Text('Estas pantallas se activan cuando la Fase 3 confirme que el '
              'telefono puede hablar ADB con tu TV. Hasta entonces no se muestran datos '
              'simulados ni se modifica nada.'),
        ),
        for (final it in items)
          ListTile(
            enabled: false,
            leading: Icon(it.$1),
            title: Text(it.$2),
            subtitle: Text(it.$3),
          ),
      ]),
    );
  }
}

// 10. Historial (datos reales de SQLite)
class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Historial')),
      body: FutureBuilder<List<Map<String, Object?>>>(
        future: Db.devices(),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final rows = snap.data!;
          if (rows.isEmpty) return const Center(child: Text('Aun no hay televisores guardados.'));
          return ListView(children: [
            for (final r in rows)
              ListTile(
                leading: const Icon(Icons.tv),
                title: Text('${r['host']}'),
                subtitle: Text('Visto: ${DateTime.fromMillisecondsSinceEpoch(r['last_seen'] as int)}'),
              ),
          ]);
        },
      ),
    );
  }
}
