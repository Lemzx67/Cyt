// Fase 2: puente Dart <-> Kotlin (NsdManager) para descubrimiento mDNS.
import 'dart:async';
import 'package:flutter/services.dart';

class TvCandidate {
  final String host;
  final Map<String, int> ports = {}; // tipo de servicio -> puerto
  final Set<String> names = {};
  TvCandidate(this.host);

  bool get hasConnect => ports.containsKey('_adb-tls-connect._tcp');
  bool get hasPairing => ports.containsKey('_adb-tls-pairing._tcp');
  bool get hasLegacyAdb => ports.containsKey('_adb._tcp');
  bool get hasRemote => ports.containsKey('_androidtvremote2._tcp');
}

class Discovery {
  static const _m = MethodChannel('cyt/discovery');
  static const _e = EventChannel('cyt/discovery/events');

  final _hosts = <String, TvCandidate>{};
  final _ctrl = StreamController<List<TvCandidate>>.broadcast();
  StreamSubscription? _sub;

  Stream<List<TvCandidate>> get stream => _ctrl.stream;
  List<TvCandidate> get current => _hosts.values.toList();

  Future<void> start() async {
    _sub ??= _e.receiveBroadcastStream().listen(_onEvent, onError: _ctrl.addError);
    await _m.invokeMethod('start');
  }

  Future<void> stop() async {
    await _m.invokeMethod('stop');
    await _sub?.cancel();
    _sub = null;
  }

  void _onEvent(dynamic ev) {
    final m = Map<String, dynamic>.from(ev as Map);
    final type = m['type'] as String;
    final name = m['name'] as String;
    if (m['event'] == 'found') {
      final host = m['host'] as String;
      final c = _hosts.putIfAbsent(host, () => TvCandidate(host));
      c.ports[type] = m['port'] as int;
      c.names.add(name);
    } else if (m['event'] == 'lost') {
      for (final c in _hosts.values) {
        if (c.names.contains(name)) c.ports.remove(type);
      }
      _hosts.removeWhere((_, c) => c.ports.isEmpty);
    }
    _ctrl.add(current);
  }
}
